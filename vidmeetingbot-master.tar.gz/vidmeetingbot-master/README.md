<h1 align="center">Videomeeting Bot</h1>
<h3 align="center">A Python/Selenium Bot which automatically joins your meeting.</h3>

- 🏴 Languages: **Danish,English,Spanish,Finnish,French,German,Italian,Polish,Portuguese,Romanian,Russish**

- 🔦 Working on: **New platforms,Other browser compatibility**

- 🌍 Browsers: **Chrome,Firefox**

- 🎥 Supported Platforms: **BigBlueButton**

- ♦ Made with: **Python,Selenium**

- ❓Questions **Join discord https://discord.gg/YmyssQZ**


