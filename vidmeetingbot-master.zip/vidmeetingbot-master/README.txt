============IGONRE FOLLOWING FILES============
chromedriver.exe
geckodriver.exe
geckodriver.log
main.py
README.md
============FILES YOU CAN USE================
Chrome User? - Use "Chrome-Versions(Chrome User)" Folder
Firefox User? - Use "Firefox-Versions(Firefox User)" Folder
============NOTICE================
If you want to edit or work with it in an IDE, install selenium
===Install Selenium===
-> pip install selenium
======
Make sure having the chromedriver/geckodriver in path when you're using the Python Files.
======
Thanks for using at see you.
It'll be cool when you would contribute in this project.
--Cheers--
</> by JuSoft in 2021

https://jusoft.dev
https://discord.gg/YmyssQZ